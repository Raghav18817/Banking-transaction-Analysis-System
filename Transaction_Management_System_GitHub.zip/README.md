# Transaction Management System

A C-based transaction management system demonstrating sorting, searching, CRUD operations, reporting, and performance comparison.

## Features
- Add, update, delete, and display transactions
- Generate sample transaction datasets
- Merge Sort and Quick Sort
- Binary Search by Transaction ID or Customer ID
- High/low amount reports
- Customer-based filtering
- Performance comparison for different dataset sizes

## Technologies
- C
- Standard C libraries
- Data Structures and Algorithms

## How to Run

Compile:
```bash
gcc transaction_management_system.c -o transaction_management_system
```

Run:
```bash
./transaction_management_system
```

On Windows:
```bash
transaction_management_system.exe
```
