#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX 10000

typedef struct {
    char id[20], customerID[20], date[15], type[10];
    double amount;
} Transaction;

Transaction txs[MAX], tmpBuf[MAX];
int n = 0, sortedField = 0;
long long comparisons = 0, recursiveCalls = 0;

void resetStats(void) { comparisons = recursiveCalls = 0; }

void swapTx(Transaction *a, Transaction *b) {
    Transaction t = *a; *a = *b; *b = t;
}

int compareDates(const char *d1, const char *d2) {
    int d1_d, d1_m, d1_y, d2_d, d2_m, d2_y;
    sscanf(d1, "%d-%d-%d", &d1_d, &d1_m, &d1_y);
    sscanf(d2, "%d-%d-%d", &d2_d, &d2_m, &d2_y);
    if (d1_y != d2_y) return d1_y - d2_y;
    if (d1_m != d2_m) return d1_m - d2_m;
    return d1_d - d2_d;
}

int compareTx(const Transaction *a, const Transaction *b, int field) {
    comparisons++;
    switch (field) {
        case 1: return strcmp(a->id, b->id);
        case 2: return strcmp(a->customerID, b->customerID);
        case 3: return compareDates(a->date, b->date);
        case 4: return (a->amount > b->amount) - (a->amount < b->amount);
        default: return 0;
    }
}

void printHeader(void) {
    printf("\n%-15s %-15s %-12s %-10s %12s\n", "TX ID", "Customer ID", "Date", "Type", "Amount");
    printf("-----------------------------------------------------------------\n");
}

void printTx(const Transaction *t) {
    printf("%-15s %-15s %-12s %-10s %12.2f\n", t->id, t->customerID, t->date, t->type, t->amount);
}

void displayAll(void) {
    if (!n) { printf("\nNo records available.\n"); return; }
    printHeader();
    for (int i = 0; i < n; i++) printTx(&txs[i]);
}

void inputFields(Transaction *t, int mask) {
    if (mask & 1) { printf("Customer ID: "); scanf("%19s", t->customerID); }
    if (mask & 2) { printf("Date (DD-MM-YYYY): "); scanf("%14s", t->date); }
    if (mask & 4) { printf("Type (CREDIT/DEBIT): "); scanf("%9s", t->type); }
    if (mask & 8) { printf("Amount: "); scanf("%lf", &t->amount); }
}

void addTransaction(void) {
    if (n >= MAX) { printf("\nDataset full.\n"); return; }
    printf("\nEnter Transaction ID: ");
    scanf("%19s", txs[n].id);
    inputFields(&txs[n], 15);
    n++;
    sortedField = 0;
    printf("Transaction added successfully.\n");
}

void updateTransaction(void) {
    if (!n) { printf("\nNo transactions available to update.\n"); return; }
    char id[20];
    int choice;
    printf("\nEnter Transaction ID to update: ");
    scanf("%19s", id);

    for (int i = 0; i < n; i++) {
        if (strcmp(txs[i].id, id) == 0) {
            printHeader();
            printTx(&txs[i]);
            printf("\n1.Cust ID  2.Date  3.Type  4.Amount  5.All  6.Cancel\nChoice: ");
            scanf("%d", &choice);
            if (choice >= 1 && choice <= 4) inputFields(&txs[i], 1 << (choice - 1));
            else if (choice == 5) inputFields(&txs[i], 15);
            else return;
            sortedField = 0;
            printf("Updated successfully.\n");
            return;
        }
    }
    printf("Transaction ID '%s' not found.\n", id);
}

void deleteTransaction(void) {
    if (!n) { printf("\nNo transactions available to delete.\n"); return; }
    char id[20];
    printf("\nEnter Transaction ID to delete: ");
    scanf("%19s", id);

    int idx = -1;
    for (int i = 0; i < n; i++) {
        if (strcmp(txs[i].id, id) == 0) {
            idx = i;
            break;
        }
    }

    if (idx == -1) {
        printf("Transaction ID '%s' not found.\n", id);
        return;
    }

    for (int i = idx; i < n - 1; i++) {
        txs[i] = txs[i + 1];
    }
    n--;
    printf("Transaction '%s' deleted successfully. (%d remaining)\n", id, n);
}

void fillSampleData(Transaction *arr, int count, int seed) {
    srand(seed);
    for (int i = 0; i < count; i++) {
        sprintf(arr[i].id, "TX%05d", i + 1);
        sprintf(arr[i].customerID, "C%04d", (rand() % 1000) + 1);
        sprintf(arr[i].date, "%02d-%02d-2026", (rand() % 28) + 1, (rand() % 12) + 1);
        strcpy(arr[i].type, (rand() % 2) ? "CREDIT" : "DEBIT");
        arr[i].amount = 100.0 + (rand() % 99901);
    }
}

void generateDataset(void) {
    printf("\nEnter number of transactions (1-%d): ", MAX);
    scanf("%d", &n);
    if (n <= 0 || n > MAX) { n = 0; printf("Invalid size.\n"); return; }
    fillSampleData(txs, n, (unsigned)time(NULL));
    sortedField = 0;
    printf("%d transactions generated.\n", n);
}

void merge(Transaction arr[], int l, int m, int r, int f) {
    int i = l, j = m + 1, k = l;
    while (i <= m && j <= r)
        tmpBuf[k++] = (compareTx(&arr[i], &arr[j], f) <= 0) ? arr[i++] : arr[j++];
    while (i <= m) tmpBuf[k++] = arr[i++];
    while (j <= r) tmpBuf[k++] = arr[j++];
    for (i = l; i <= r; i++) arr[i] = tmpBuf[i];
}

void mergeSort(Transaction arr[], int l, int r, int f) {
    recursiveCalls++;
    if (l < r) {
        int m = l + (r - l) / 2;
        mergeSort(arr, l, m, f);
        mergeSort(arr, m + 1, r, f);
        merge(arr, l, m, r, f);
    }
}

int partition(Transaction arr[], int low, int high, int f) {
    int mid = low + (high - low) / 2, i = low - 1;
    if (compareTx(&arr[mid], &arr[low], f) < 0) swapTx(&arr[low], &arr[mid]);
    if (compareTx(&arr[high], &arr[low], f) < 0) swapTx(&arr[low], &arr[high]);
    if (compareTx(&arr[mid], &arr[high], f) < 0) swapTx(&arr[mid], &arr[high]);

    Transaction pivot = arr[high];
    for (int j = low; j < high; j++) {
        if (compareTx(&arr[j], &pivot, f) <= 0) swapTx(&arr[++i], &arr[j]);
    }
    swapTx(&arr[i + 1], &arr[high]);
    return i + 1;
}

void quickSort(Transaction arr[], int low, int high, int f) {
    recursiveCalls++;
    while (low < high) {
        int pi = partition(arr, low, high, f);
        if (pi - low < high - pi) {
            quickSort(arr, low, pi - 1, f);
            low = pi + 1;
        } else {
            quickSort(arr, pi + 1, high, f);
            high = pi - 1;
        }
    }
}

void sortTransactions(void) {
    if (!n) { printf("\nNo transactions available.\n"); return; }
    int field, algo;
    printf("\nSort by: 1.ID  2.Customer ID  3.Date  4.Amount: ");
    scanf("%d", &field);
    if (field < 1 || field > 4) return;
    printf("Algorithm: 1.Merge Sort  2.Quick Sort: ");
    scanf("%d", &algo);

    resetStats();
    clock_t t0 = clock();
    if (algo == 1) mergeSort(txs, 0, n - 1, field);
    else if (algo == 2) quickSort(txs, 0, n - 1, field);
    else return;

    double ms = ((double)(clock() - t0) / CLOCKS_PER_SEC) * 1000.0;
    sortedField = field;
    printf("Sorted in %.3f ms | Comparisons: %lld | Recursive calls: %lld\n", ms, comparisons, recursiveCalls);
}

int binarySearch(Transaction arr[], int size, const char *key, int field) {
    int low = 0, high = size - 1;
    while (low <= high) {
        int mid = low + (high - low) / 2;
        comparisons++;
        int cmp = strcmp(field == 1 ? arr[mid].id : arr[mid].customerID, key);
        if (!cmp) return mid;
        if (cmp < 0) low = mid + 1;
        else high = mid - 1;
    }
    return -1;
}

void searchTransaction(void) {
    if (!n) { printf("\nNo records available.\n"); return; }
    int field;
    char key[30];
    printf("\nSearch by: 1.Transaction ID  2.Customer ID: ");
    scanf("%d", &field);
    if (field != 1 && field != 2) return;
    if (sortedField != field) {
        printf("Records must be sorted by selected field first.\n");
        return;
    }
    printf("Enter key: ");
    scanf("%29s", key);
    resetStats();
    int idx = binarySearch(txs, n, key, field);
    if (idx >= 0) {
        printHeader();
        printTx(&txs[idx]);
    } else printf("Record not found.\n");
    printf("Comparisons: %lld\n", comparisons);
}

void generateReports(void) {
    if (!n) { printf("\nNo records available.\n"); return; }
    int choice;
    printf("\n1.High/Low Amount  2.Customer Filter: ");
    scanf("%d", &choice);

    if (choice == 1) {
        int hi = 0, lo = 0;
        for (int i = 1; i < n; i++) {
            if (txs[i].amount > txs[hi].amount) hi = i;
            if (txs[i].amount < txs[lo].amount) lo = i;
        }
        printHeader();
        printf("[HIGHEST]\n"); printTx(&txs[hi]);
        printf("[LOWEST]\n");  printTx(&txs[lo]);
    } else if (choice == 2) {
        char cust[20];
        int count = 0;
        printf("Enter Customer ID: ");
        scanf("%19s", cust);
        printHeader();
        for (int i = 0; i < n; i++) {
            if (strcmp(txs[i].customerID, cust) == 0) { printTx(&txs[i]); count++; }
        }
        if (!count) printf("No records found for %s.\n", cust);
    }
}

void performanceComparison(void) {
    int sizes[] = {100, 500, 1000, 5000, 10000};
    Transaction *orig = malloc(MAX * sizeof(Transaction));
    Transaction *copy = malloc(MAX * sizeof(Transaction));
    if (!orig || !copy) { free(orig); free(copy); return; }

    printf("\n%-7s %-12s %-14s %-12s %-10s\n", "Size", "Algorithm", "Comparisons", "Recursions", "Time (ms)");
    printf("----------------------------------------------------------\n");

    for (int i = 0; i < 5; i++) {
        int sz = sizes[i];
        fillSampleData(orig, sz, 100 + sz);

        for (int algo = 1; algo <= 2; algo++) {
            memcpy(copy, orig, sz * sizeof(Transaction));
            resetStats();
            clock_t t0 = clock();
            if (algo == 1) mergeSort(copy, 0, sz - 1, 4);
            else quickSort(copy, 0, sz - 1, 4);
            double ms = ((double)(clock() - t0) / CLOCKS_PER_SEC) * 1000.0;
            printf("%-7d %-12s %-14lld %-12lld %-10.4f\n",
                   sz, algo == 1 ? "Merge Sort" : "Quick Sort", comparisons, recursiveCalls, ms);
        }
        printf("----------------------------------------------------------\n");
    }
    free(orig);
    free(copy);
}

int main(void) {
    int choice;
    do {
        printf("\n1.Add  2.Generate  3.Display  4.Edit  5.Delete  6.Sort  7.Search  8.Report  9.Bench  10.Exit\nChoice: ");
        if (scanf("%d", &choice) != 1) break;
        switch (choice) {
            case 1:  addTransaction(); break;
            case 2:  generateDataset(); break;
            case 3:  displayAll(); break;
            case 4:  updateTransaction(); break;
            case 5:  deleteTransaction(); break;
            case 6:  sortTransactions(); break;
            case 7:  searchTransaction(); break;
            case 8:  generateReports(); break;
            case 9:  performanceComparison(); break;
            case 10: printf("Exiting.\n"); break;
            default: printf("Invalid choice.\n");
        }
    } while (choice != 10);
    return 0;
}
